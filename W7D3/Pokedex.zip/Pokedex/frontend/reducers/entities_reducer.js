import {combineReducers} from 'redux';
import pokemon from './pokemon_reducer';

export default combineReducers({
  pokemon
});
